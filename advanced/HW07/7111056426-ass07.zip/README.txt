cmd 下指令

程式-1：python 1_VOH_measure.py 執行檔案
程式-2：python 2_CHI_measure.py 執行檔案
程式-3：python 3_COR_measure.py 執行檔案
程式-4：python 4_GIE_meausre.py 執行檔案

csv 結果請至 statis 資料夾下看

P.S 程式3 寫的可能不太正確，想像老師上課說的點水平、垂直、對角都在同個slot裡，
但發現 M > l (floor(L/K))的狀況下好像根本不可能QQ