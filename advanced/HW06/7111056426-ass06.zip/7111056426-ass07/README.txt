cmd 下指令
加密 python 7111056426-06-3D-NEAT_enc.py 執行檔案
解密 python 7111056426-06-3D-NEAT_dec.py 執行檔案

依照提示輸入bx, by, bz, rx, ry, rz:
範例輸入 bx, by, bz, rx, ry, rz: 1 1 1 1 1 1

加密次數 L=5

加密後圖片至 encryp 資料夾看
解密後圖片至 decryp 資料夾看

其他參數依題目指示存在 parame/parameter.txt

P.S 程式沒有寫很好，會跑有點久(每張圖片約6分鐘)，抱歉><，但是可以跑得

python 沒有 image.type() 自動判斷影像為灰階或是彩色型態
只能轉灰階，再算rgb 3個channel是否相等，但覺得沒有讓程式快一點
有自動判斷影像為灰階或是彩色型態的版本
加密 python 7111056426-06-3D-NEAT_enc_gray.py 執行檔案
解密 python 7111056426-06-3D-NEAT_dec_gray.py 執行檔案