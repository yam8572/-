cmd 下指令
python 7111056426-03-IEEE conversion.py 執行檔案

依照選單提示輸入所需功能
選單 1: Decimal to IEEE-754 按 1
選單 2: IEEE-754 to Decimal 按 2
選單 3: 結束程式 按 3

功能完成會出現提示訊息
選 1 Decimal to IEEE-754 完成 ! 請至 output 資料夾下 bin 資料夾看轉換結果
選 2 IEEE-754 to Decimal 完成 ! 請至 output 資料夾下 dec 資料夾看轉換結果
選 3 結束程式
其他輸入 "無此選單，請依選單輸入 1 2 3"