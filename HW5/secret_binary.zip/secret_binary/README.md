嵌入binary(0、1)

資料夾說明:
source 為老師給的來源圖
cover 為轉為灰階的圖片
stego 為嵌入密碼後的圖片
secret 為嵌入密碼的密碼文字檔

輸入範例:
1. n≥2, n≤10 為正整數 n: number of pixels in a cluster: 5
2. 輸入 cover image: 4.2.05.png
